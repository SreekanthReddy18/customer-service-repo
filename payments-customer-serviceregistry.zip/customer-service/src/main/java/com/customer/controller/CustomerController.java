package com.customer.controller;

import org.apache.juli.logging.Log;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.customer.proxy.PaymentsServiceproxy;

@RefreshScope
@RestController
@RequestMapping("/customer")
public class CustomerController {

	static final java.util.logging.Logger logger=java.util.logging.Logger.getLogger(CustomerController.class.getName());
	
	@Autowired
	PaymentsServiceproxy paymentsServiceProxy;
	
	@RequestMapping(value="find/{id}", method=RequestMethod.GET)
	public ResponseEntity<String> test(@PathVariable Long id){
		
		logger.info("Entered in Customer controller");
		return paymentsServiceProxy.findById(id);
	}
	
}
