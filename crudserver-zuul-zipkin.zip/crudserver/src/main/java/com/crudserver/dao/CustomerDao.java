package com.crudserver.dao;

import java.util.Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.crudserver.entity.Customer;

public interface CustomerDao extends CrudRepository<Customer, Integer>{
	
	@Query(
			  value = "SELECT * FROM PAYMENT u WHERE u.customer_Id = :customerId", 
			  nativeQuery = true)
	public Collection<Customer> getAllPayments(@Param("customerId") String customerId);

}
