package com.crudserver.dao;

import org.springframework.data.repository.CrudRepository;

import com.crudserver.entity.Payment;

public interface PaymentDao extends CrudRepository<Payment, Integer> {

	
}
