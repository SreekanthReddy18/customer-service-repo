package com.crudserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crudserver.dao.CustomerDao;
import com.crudserver.entity.Customer;
import com.crudserver.model.CustomerDto;

@RestController
@RequestMapping("/crud")
public class CrudController {

	@Autowired
	CustomerDao customerDao;
	
	@RequestMapping(value="save/customer", method=RequestMethod.POST)
	public ResponseEntity<Customer> saveCustomer(@RequestBody CustomerDto customerDto){
		
//		Payment payment = new 
//		
//		Customer customer = new Customer(customerDto.getCustomerId(),customerDto.getCustomerName(),
//				customerDto.getCustomerType(),customer.getAddress1(),customerDto.getAddress2(),customerDto.getCity(),
//				customerDto.getState(),customerDto.getPostalCode(),customerDto.getCountry(),customerDto.getEmail(),
//				customerDto.getPhone(),customerDto.getFax(),customerDto.getPaymentList());
//		
//		customerDao.save(customer);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@RequestMapping(value="test", method=RequestMethod.GET)
	public ResponseEntity<String> test(){
		

		return new ResponseEntity<>("Success",HttpStatus.OK);
	}
	
	
}
