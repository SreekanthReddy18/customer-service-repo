package com.payments.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.payments.proxy.CrudServiceProxy;

@RestController
@RequestMapping("/payments")
public class PaymentsController {

	@Autowired
	CrudServiceProxy crudServiceProxy;
	
	@RequestMapping(value="find/{id}", method=RequestMethod.GET)
	public ResponseEntity<String> test(@PathVariable Long id){
		

		return new ResponseEntity<>("Success-"+id+" !!",HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAll/payments/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getAllPayments(@PathVariable String id){
		

		return new ResponseEntity<Object>(crudServiceProxy.getAllPayments(id),HttpStatus.OK);
	}
	
	@RequestMapping(value="/delete/payment/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<String> deletePayment(@PathVariable String id){
		
		crudServiceProxy.deletePayment(id);

		return new ResponseEntity<String>("Successfully deleted",HttpStatus.OK);
	}
	
	@RequestMapping(value="/get/payment/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getPaymentById(@PathVariable String id){
		

		return new ResponseEntity<Object>(crudServiceProxy.getPaymentById(id),HttpStatus.OK);
	}
	
}
