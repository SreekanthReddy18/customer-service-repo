package com.payments.proxy;

import java.util.Iterator;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@FeignClient(name="crud-service")
public interface CrudServiceProxy {

	@RequestMapping(value="/crud/getAll/payments/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getAllPayments(@PathVariable String id);
	
	@RequestMapping(value="/crud/delete/payment/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Void> deletePayment(@PathVariable String id);
	
	@RequestMapping(value="/crud/get/payment/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getPaymentById(@PathVariable String id);

}
