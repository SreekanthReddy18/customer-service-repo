package com.crudserver.dao;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.crudserver.entity.Customer;

public interface CustomerDao extends JpaRepository<Customer, Integer>{
	
	

}
