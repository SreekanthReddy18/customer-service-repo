package com.crudserver.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crudserver.dao.CustomerDao;
import com.crudserver.dao.PaymentDao;
import com.crudserver.entity.Customer;
import com.crudserver.entity.Payment;
import com.crudserver.model.CustomerDto;
import com.crudserver.model.PaymentDto;

@RestController
@RequestMapping("/crud")
public class CrudController {

	@Autowired
	CustomerDao customerDao;
	
	@Autowired
	PaymentDao paymentDao;
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public ResponseEntity<Object> save(@RequestBody CustomerDto customerDto){
		
		
		Customer customer = new Customer();
		customer.setCustomerId(customerDto.getCustomerId());
		customer.setCustomerName(customerDto.getCustomerName());
		customer.setCustomerType(customerDto.getCustomerType());
		customer.setAddress1(customerDto.getAddress1());
		customer.setAddress2(customerDto.getAddress2());
		customer.setCity(customerDto.getCity());
		customer.setState(customerDto.getState());
		customer.setPostalCode(customerDto.getPostalCode());
		customer.setCountry(customerDto.getCountry());
		customer.setEmail(customerDto.getEmail());
		customer.setPhone(customerDto.getPhone());
		customer.setFax(customerDto.getFax());
		
		customerDao.save(customer);
		Iterator<PaymentDto> it = customerDto.getPaymentList().iterator();
		
		Payment entity = null;
		
		 while (it.hasNext()) {
			  
	            PaymentDto  payment = it.next();
	            entity = new Payment(payment.getPaymentId(), payment.getAmount(),
	            		payment.getCreditType(), payment.getDescription(), customer);
	            paymentDao.save(entity);
	        }
		
		return new ResponseEntity<Object>(getAllCustomersList(),HttpStatus.CREATED);
	}
	
	@RequestMapping(value="test", method=RequestMethod.GET)
	public ResponseEntity<String> test(){
		

		return new ResponseEntity<>("Success",HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAll/customers", method=RequestMethod.GET)
	public ResponseEntity<List<CustomerDto>> getAllCustomers(){
		
				return new ResponseEntity<List<CustomerDto>>(getAllCustomersList(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/get/customer/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getCustomerById(@PathVariable String id){
		

		return new ResponseEntity<Object>(customerDao.findById(Integer.valueOf(id)),HttpStatus.OK);
	}
	
	@RequestMapping(value="/delete/customer/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Void> deleteCustomerById(@PathVariable String id){
		customerDao.deleteById(Integer.valueOf(id));

		return new ResponseEntity<Void>( HttpStatus.OK);
	}
	
	@RequestMapping(value="/update/customer", method=RequestMethod.PUT)
	public ResponseEntity<Void> updateCustomer(@RequestBody CustomerDto customerDto){
		
		Customer customer = new Customer();
		customer.setCustomerId(customerDto.getCustomerId());
		customer.setCustomerName(customerDto.getCustomerName());
		customer.setCustomerType(customerDto.getCustomerType());
		customer.setAddress1(customer.getAddress1());
		customer.setAddress2(customerDto.getAddress2());
		customer.setCity(customerDto.getCity());
		customer.setPhone(customerDto.getPhone());
		customer.setFax(customerDto.getFax());
		
		customerDao.save(customer);
		Iterator<PaymentDto> it = customerDto.getPaymentList().iterator();
		
		
		/*Payment entity = null;
		
		 while (it.hasNext()) {
			  
	            System.out.print(it.next() + " ");
	            PaymentDto  payment = it.next();
	            entity = new Payment(payment.getPaymentId(), payment.getAmount(),
	            		payment.getCreditType(), payment.getDescription(), customer);
	            paymentDao.save(entity);
	        }*/
		
		return new ResponseEntity<>(HttpStatus.OK);

	}
	@RequestMapping(value="/getAll/payments/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getAllPayments(@PathVariable String id){
		

		return new ResponseEntity<Object>(paymentDao.getAllPayments(Integer.valueOf(id)),HttpStatus.OK);
	}
	
	@RequestMapping(value="/delete/payment/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Void> deletePayment(@PathVariable String id){
		
		paymentDao.deleteById(Integer.valueOf(id));

		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/get/payment/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getPaymentById(@PathVariable String id){
		

		return new ResponseEntity<Object>(paymentDao.findById(Integer.valueOf(id)),HttpStatus.OK);
	}
	
	public List<CustomerDto>  getAllCustomersList() {
		
		List<Customer> customers = customerDao.findAll();
		List<CustomerDto> customerDtoList  = new ArrayList<>();
		customers.stream().forEach(customer ->{
			Set<PaymentDto> paymentDtoList = new HashSet<>();
			if(customer.getPaymentList()!=null) {
			customer.getPaymentList().stream().forEach(payment-> {
				PaymentDto paymentDto  = new PaymentDto();
				paymentDto.setPaymentId(payment.getPaymentId());
				paymentDto.setAmount(payment.getAmount());
				paymentDto.setCreditType(payment.getCreditType());
				paymentDto.setDescription(payment.getDescription());
				paymentDtoList.add(paymentDto);
			});
			}
			CustomerDto  customerDto = new CustomerDto(customer.getCustomerId(),
					customer.getCustomerName(),
					customer.getCustomerType(),
					customer.getAddress1(),
					customer.getAddress2(),
					customer.getCity(),
					customer.getState(),
					customer.getPostalCode(),
					customer.getCountry(),
					customer.getEmail(),
					customer.getPhone(),
					customer.getFax(),
					paymentDtoList);
			customerDtoList.add(customerDto);
			
		});

		return customerDtoList;
	}
}
