package com.customer.controller;

import java.util.Iterator;
import java.util.List;

import org.apache.juli.logging.Log;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.customer.model.CustomerDto;
import com.customer.proxy.CrudServiceProxy;
import com.customer.proxy.PaymentsServiceproxy;

@RefreshScope
@RestController
@RequestMapping("/customer")
public class CustomerController {

	static final java.util.logging.Logger logger=java.util.logging.Logger.getLogger(CustomerController.class.getName());
	
	@Autowired
	PaymentsServiceproxy paymentsServiceProxy;
	
	@Autowired
	CrudServiceProxy crudServiceProxy;
	
	@RequestMapping(value="find/{id}", method=RequestMethod.GET)
	public ResponseEntity<String> test(@PathVariable Long id){
		
		logger.info("Entered in Customer controller");
		return paymentsServiceProxy.findById(id);
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public ResponseEntity<Object> save(@RequestBody CustomerDto customerDto){
		
		
	return new ResponseEntity<Object>(crudServiceProxy.save(customerDto),HttpStatus.CREATED);
	}
	
	@RequestMapping(value="test", method=RequestMethod.GET)
	public ResponseEntity<String> test(){
		

		return new ResponseEntity<>("Success",HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAll/customers", method=RequestMethod.GET)
	public ResponseEntity<Object> getAllCustomers(){
		

		return new ResponseEntity<Object>(crudServiceProxy.getAllCustomers(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/get/customer/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getCustomerById(@PathVariable String id){
		

		return new ResponseEntity<Object>(crudServiceProxy.getCustomerById(id),HttpStatus.OK);
	}
	
	@RequestMapping(value="/delete/customer/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Void> deleteCustomerById(@PathVariable String id){
		crudServiceProxy.deleteCustomerById(id);

		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/update/customer", method=RequestMethod.PUT)
	public ResponseEntity<Object> updateCustomer(@RequestBody CustomerDto customerDto){
	
	return new ResponseEntity<Object>(crudServiceProxy.updateCustomer(customerDto),HttpStatus.OK);

	}
	
}
