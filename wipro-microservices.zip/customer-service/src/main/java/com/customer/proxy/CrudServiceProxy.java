package com.customer.proxy;

import java.util.Iterator;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.customer.model.CustomerDto;

@FeignClient(name="crud-service")
public interface CrudServiceProxy {

	@RequestMapping(value="/crud/save", method=RequestMethod.POST)
	public ResponseEntity<Object> save(@RequestBody CustomerDto customerDto);
	
	@RequestMapping(value="/crud/getAll/customers", method=RequestMethod.GET)
	public ResponseEntity<List<CustomerDto>> getAllCustomers();
	
	@RequestMapping(value="/crud/get/customer/{id}", method=RequestMethod.GET)
	public ResponseEntity<Object> getCustomerById(@PathVariable String id);
	
	@RequestMapping(value="/crud/delete/customer/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Void> deleteCustomerById(@PathVariable String id);
	
	@RequestMapping(value="/crud/update/customer", method=RequestMethod.PUT)
	public ResponseEntity<Void> updateCustomer(@RequestBody CustomerDto customerDto);
}
